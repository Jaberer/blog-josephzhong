{
  "name": "Personal",
  "slug": "personal",
  "version": "1.0.0",
  "widget-areas": [
  	"widgets-area-a"
  ]
}